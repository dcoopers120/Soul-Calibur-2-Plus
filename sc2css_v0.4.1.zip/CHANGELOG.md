﻿# Changelog

## [0.4.1]
### Added
- Support for SC2 Plus Practice 0.9.6.1 DOL
## [0.4.0]
### Added
- Weapon Master character select screen editor
- (Xbox) Center CSS Option
### Fixed
 - Editing a copied entry would modify the original entry.

## [0.3.0]
### Added
 - Xbox/PS2 NTSC-U support. Center CSS option still needs to be added.
 - CSS character index option. Used when returning to the CSS after a match.

## [0.2.1]
### Fixed
- Values not being set when loading another dol

## [0.2.0]
### Added
- Individual values can be modified.
- Character info editor. Can only view/edit the costume count for now.
- Option to center CSS entries if using the 5th column.


## [0.1.0]
- Initial Release.
- Data between entries can be copied/pasted.