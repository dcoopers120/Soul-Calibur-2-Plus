﻿# Soul Calibur 2 CSS Editor

Allows you to modify the character select screen entries.


## How to use
Load main.dol and edit whichever values you want. Right click an entry to copy/paste data to another one. Click File > Save once you're finished.

Backup your files just to be safe.

### Adding Costumes
Using Link as an example, inject a pkg file to File948 with another program. Click on his CSS entry and increase the Costumes value by 1. Change the character icon and BG values for the 5th slot so it doesn't default to Mitsurugi's. After that click Edit > Character Info Editor, choose Link in the drop down box, and increase the Costumes value there by 1 as well. Once you save you should be able to select an extra costume in-game.

## To Do:
- Add support for more versions/regions.
- Add more values to Character Info Editor.
- Improve UI and label more unknown values.

